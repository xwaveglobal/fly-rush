# Sky Roadster Step 03 — Complete Reference Package

## Design priority
1. 01_XWAVE_Original_Reference_Kit/01_authoritative/XWAVE_REAR_0_MASTER_DO_NOT_OVERRIDE.png — authoritative XWAVE design.
2. 02_Tesla_Aero_References — aerodynamic inspiration ONLY: integrated lower bumper/diffuser and flush active spoiler. Do not copy Tesla branding, lights, or full car geometry.
3. 03_Current_Game_Screenshots — actual current home views, show diffuser rods and UI overlap.
4. 04_Gameplay_Video — actual gameplay and contact sheet for camera/motion assessment.
5. Other AI views in 01_XWAVE_Original_Reference_Kit are secondary and may be inconsistent.

## Required corrections
- Remove dangling rods and chrome tubes, not merely recolor them.
- Build integrated satin-black low-profile diffuser with restrained embedded fins.
- Flush active spoiler at rest, deploy subtly during Nitro.
- Preserve XWAVE LED, badge and original rear silhouette.
- Improve Home and gameplay cameras separately, preserve gameplay/hitboxes.

Use the revised Step 03 prompt provided in chat. Existing GLB/model sources are in the Git repo from Step 02; this ZIP contains references, not a replacement GLB.
